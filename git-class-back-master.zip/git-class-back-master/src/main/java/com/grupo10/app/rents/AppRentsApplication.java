package com.grupo10.app.rents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppRentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppRentsApplication.class, args);
	}

}
